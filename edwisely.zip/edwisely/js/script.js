(function ($) {
    "use strict";
    /*Style Switcher*/
    $(".holder a").on("click", function (e) {
        e.preventDefault();
        var style = "assets/css/" + $(this).data("switchcolor");
        $("#color-switcher").attr("href", style);
        $(this).parent().parent().find("a").removeClass("active");
        $(this).addClass("active");
    });
    jQuery('.switcher .icon').click(function () {
        if (jQuery('.switcher').hasClass("active")) {
            jQuery('.switcher').animate({"right": "-220px"}, function () {
                jQuery('.switcher').toggleClass("active");
            });
        } else {
            jQuery('.switcher').animate({"right": "0px"}, function () {
                jQuery('.switcher').toggleClass("active");
            });
        }
    });
}(jQuery));